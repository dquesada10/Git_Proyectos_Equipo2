import csv
import pandas as pd
from rdflib import Graph, Literal, URIRef, Namespace, BNode
from rdflib.namespace import RDF

df = pd.read_csv("stops_final.txt", sep=',')
df

FOAF = Namespace('http://xmlns.com/foaf/0.1/')
w3 = Namespace("http://www.w3.org/1999/02/22-rdf-syntax-ns#")
sch = Namespace("http://schema.org/")
CRTM = Namespace("http://crtm.es/")
etd = Namespace("http://e-tourism.deri.at/ont/e-tourism.owl/")

G = Graph()

Code = URIRef("http://xmlns.com/foaf/0.1/Code")
Name = URIRef("http://xmlns.com/foaf/0.1/Name")
Adress = URIRef("http://xmlns.com/foaf/0.1/Desc")
Latitud = URIRef("http://www.w3.org/1999/02/22-rdf-syntax-ns#/Latitud")
Longitud = URIRef("http://www.w3.org/1999/02/22-rdf-syntax-ns#/Longitud")
ZoneID = URIRef("http://schema.org/ZoneID")
URL = URIRef("http://crtm.es/URL")
Type = URIRef("http://schema.org/Type")
ParentID = URIRef('http://www.ontologies.org/ParentID')
ParentName = URIRef('http://www.ontologies.org/ParentName')
TimeZone = URIRef('http://www.ontologies.org/TimeZone')
WheelChair = URIRef("http://e-tourism.deri.at/ont/e-tourism.owl/WheelChair")
TransportName = URIRef("http://e-tourism.deri.at/ont/e-tourism.owl/TransportName")

st = Namespace('urn:estaciones:madrid/')


for index, row in df.iterrows():
    ID = st[row['stop_id']]

    #Estaciones
    if row[9] == 1:
        G.add((ID, Type,  Literal('estacion')))
        G.add((ID, ID, Literal(row['stop_id'])))
        G.add((ID, Code, Literal(row['stop_code'])))
        G.add((ID, Name, Literal(row["stop_name"])))
        G.add((ID, Adress, Literal(row['stop_desc'])))
        G.add((ID, TransportName, Literal(row['transportmean_name'])))
        G.add((ID, Latitud, Literal(row['stop_lat'])))
        G.add((ID, Longitud, Literal(row['stop_lon'])))
        G.add((ID, ZoneID, Literal(row['zone_id'])))
        G.add((ID, URL, Literal(row['stop_url'])))
        G.add((ID, TimeZone, Literal(row['stop_timezone'])))
        G.add((ID, WheelChair, Literal(row['wheelchair_boarding'])))
        #No tienen parent_station porque son las estaciones en si mismas

    #Paradas
    if row[9] == 0:
        G.add((ID, Type,  Literal('parada')))
        G.add((ID, ID, Literal(row['stop_id'])))
        G.add((ID, Code, Literal(row['stop_code'])))
        G.add((ID, Name, Literal(row["stop_name"])))
        G.add((ID, Adress, Literal(row['stop_desc'])))
        G.add((ID, TransportName, Literal(row['transportmean_name'])))
        if not pd.isna(row[10]):
            G.add((ID, ParentID, Literal(row['parent_station'])))
            G.add((ID, ParentName, Literal(row['parent_station_name'])))
            #A veces tienen parent_station y a veces no. Si no tiene no la mostramos. Entenemos que esto courre cuando la propia parada es estación.
        G.add((ID, Latitud, Literal(row['stop_lat'])))
        G.add((ID, Longitud, Literal(row['stop_lon'])))
        G.add((ID, ZoneID, Literal(row['zone_id'])))
        G.add((ID, URL, Literal(row['stop_url'])))
        if not pd.isna(row[10]):
            G.add((ID, TimeZone, Literal(row['stop_timezone'])))
            #Si la parada es estación, como ocurre en las estaciones tiene time_zone y la mostramos.
        G.add((ID, WheelChair, Literal(row['wheelchair_boarding'])))  

    #Accesos
    elif row [9] == 2:    
        G.add((ID, Type,  Literal('acceso')))
        G.add((ID, ID, Literal(row['stop_id'])))
        G.add((ID, Code, Literal(row['stop_code'])))
        G.add((ID, Name, Literal(row["stop_name"])))
        G.add((ID, Adress, Literal(row['stop_desc'])))
        G.add((ID, TransportName, Literal(row['transportmean_name'])))
        G.add((ID, ParentID, Literal(row['parent_station'])))
        G.add((ID, ParentName, Literal(row['parent_station_name'])))
        G.add((ID, Latitud, Literal(row['stop_lat'])))
        G.add((ID, Longitud, Literal(row['stop_lon'])))
        G.add((ID, URL, Literal(row['stop_url'])))
        #G.add((ID, WheelChair, Literal(row['wheelchair_boarding']))) Siempre es cero
        #Los accesos No tienen zone_id ni time_zone ya que son accesos

        
G.bind('FOAF', FOAF)
G.bind('w3', w3)
G.bind('sch', sch)
G.bind('CRTM', CRTM)
G.bind('etd', etd)

G.serialize(destination="stops.xml", format = "xml")

print("Archivo XML generado")