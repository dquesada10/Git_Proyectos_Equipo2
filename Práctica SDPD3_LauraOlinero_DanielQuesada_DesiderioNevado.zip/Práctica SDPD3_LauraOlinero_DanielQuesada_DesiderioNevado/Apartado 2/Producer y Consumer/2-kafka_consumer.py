from kafka import KafkaConsumer
import sys, os
from datetime import datetime
import socket

def socket_connection(host, port):
    # Set up localhost socket
    conn = None
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(1)
    print("Waiting for TCP connection...")
    conn, addr = s.accept()
    print("Successfully connected...")
    return conn

if __name__ == "__main__":
    try:
        # Initialize Kafka consumer
        print("Initialization...")
        # consumer = KafkaConsumer(bootstrap_servers='172.20.1.21:9092',
        #                          auto_offset_reset='earliest')
        consumer = KafkaConsumer(bootstrap_servers='localhost:9092',
                                 auto_offset_reset='latest')
        consumer.subscribe(['iot'])

        print("Connecting to local network socket")
        connection = socket_connection("localhost", 10002)
        print("Connection established")
        print("Proceeding with data forwarding")
        # Set up forwarding to localhost socket
        for message in consumer:
            # print (message.value)
            wiki_logs_str = str(message.value)
            now = datetime.now().time() # time object
            print("Sent [", now, "]> ", wiki_logs_str)
            connection.send(message.value)

        print("End of data input")

    except KeyboardInterrupt:
        print('Interrupted from keyboard, shutdown')
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)
